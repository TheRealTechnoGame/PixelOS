#!/bin/sh
set -e

autoreconf -fiv
rm -Rf autom4te.cache
