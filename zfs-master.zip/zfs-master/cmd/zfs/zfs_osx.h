
#ifdef  __cplusplus
extern "C" {
#endif


	extern void libzfs_refresh_finder(char *);


#ifdef  __cplusplus
};
#endif
