#ifndef _LIBSPL_TIMER_H
#define _LIBSPL_TIMER_H


#endif  /* _LIBSPL_TIMER_H */
