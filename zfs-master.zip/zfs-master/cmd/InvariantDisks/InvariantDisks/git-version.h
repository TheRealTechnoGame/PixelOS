#define GIT_VERSION ""
