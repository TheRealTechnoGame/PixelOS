/*!
 * @header
 * Shim header to provide errno_t.
 */
#ifndef __IMAGE4_SHIM_SYS_TYPES_H
#define __IMAGE4_SHIM_SYS_TYPES_H

typedef int errno_t;

#endif // __IMAGE4_SHIM_SYS_TYPES_H
